#pragma once

#define HTTP_SERVER "123.30.48.187"
#define HTTP_PORT 80

#define TFTP_SERVER "123.30.48.187"
